package com.alovecino.consultaservice.dto;

import lombok.Data;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Data
public class ResponderConsultaRequest {

    @NotBlank(message = "La respuesta es obligatoria")
    private String respuesta;

    @NotNull(message = "El ID del estado de consulta es obligatorio")
    private Long idEstadoConsulta;
}
